export const API_KEY = ['free'];
export const CREATOR = '@Nevaria Api'

export const mess = {
  inapikey: "invalid apiKey",
  apikey: "apiKey required",
  method: "method not allowed",
  error: "internal server error"
};

export const footer = {
  name: "VynnoxRzy",
  url: "https://github.com/LEXXYVDEV"
};
